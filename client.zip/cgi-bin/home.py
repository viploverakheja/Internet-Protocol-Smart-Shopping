#!/usr/bin/env python
import socket #for sockets
import sys #for exit
import cgi
import json
from pprint import pprint
import threading
from time import sleep
import os
import re
import time
'''

#create an AF_INET, STREAM socket (TCP)
    sender = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
except :
    print ('Failed to create socket. Error code: ')
    sys.exit();
print ('Socket Created')
#host = '10.139.60.69'
host = 'localhost'
port = 25090
'''

form = cgi.FieldStorage()
mystring = form['pwm'].value
mystring = mystring.replace(" ","+")


#create an AF_INET, STREAM socket (TCP)
def print_AMAZON():
	try:
	    sender = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
	except :
	    print ('Failed to create socket. Error code: ')
	    sys.exit();
	print ('Socket Created')
	host = '192.168.2.5'
	port = 12305
	start_time = time.time();
	try:
	    print("trying to connect")
	    sender.connect((host , port))
	    print("connected to server")
	    sender.send(mystring)
	    with open('received_file.json', 'wb') as f:
		print ('file opened')
		while True:
		    print('receiving data...')
		    data = sender.recv(1024)
		#    print('data=%s', (data))
		    #if not data:
		     #   break
		# write data to a file
		    f.write(data)
	    	    f.close()
		    break
	    #print (sender.recv(1024)) 
	    end_time = round(time.time() - start_time)
	except:
	    print("Not able to connect")

	sender.close()

#print("Hello World!!!")

#threading.Thread(target=print_AMAZON).start()

#try: 
 #	_thread.start_new_thread(print_AMAZON,("Thread-1",0,))
 #	_thread.start_new_thread(print_Wallmart,("Thread-2",2,))
#except:
#	print ("Error: unable to start thread")

#sleep(10)
#global obj
#obj = {}

#path = os.path.abspath('../received_file.json')
#print (path)
#def print_AMAZON():

	path = os.path.abspath('received_file.json')
	with open(path) as fp:
		obj = json.load(fp)

	#try: 
	# 	_thread.start_new_thread(print_AMAZON,("Thread-1",0,))
	 #	_thread.start_new_thread(print_Wallmart,("Thread-2",2,))
	#except:
	#	print ("Error: unable to start thread")

	#print_AMAZON()

	#print obj[0]

	#print "Content-Type: text/html"
	print ""
	print "<html>"
	print "<head><title>Output</title></head>"
	print "<body>"
	print "<p>"
	print "<h1> Amazon Server Responses </h1>"
	print "Item Name:      \t" + str(obj[0]["NAME"]) + "<br>"
	#print "Item Name:      \t" 
	#print (obj[0]["NAME"]) 
	#print "<br>"
	print "Item Price:     \t" + str(obj[0]["ORIGINAL_PRICE"]) + "<br>"
	print '<a href=%s target="_blank">To order Click Here</a>'%(obj[0]["URL"])
	print "<br>"
	#print "Item link:      \t" + obj[0]["URL"] + "<br>"
	print "<br>"
	print "Item Name:      \t" + str(obj[1]["NAME"]) + "<br>"
	print "Item Price:     \t" + str(obj[1]["ORIGINAL_PRICE"]) + "<br>"
	print '<a href=%s target="_blank">To order Click Here</a>' %(obj[1]["URL"])
	#print "Item Link:      \t" + obj[1]["URL"] + "<br>"
	print "<br>"
	print "<br>"
	print "Item Name:      \t" + str(obj[2]["NAME"]) + "<br>"
	print "Item Price:     \t" + str(obj[2]["ORIGINAL_PRICE"]) + "<br>"
	print '<a href=%s target="_blank">To order Click Here</a>' %(obj[2]["URL"])
	#print "Item Link:      \t" + obj[2]["URL"] + "<br>"
	print "<br>"
	print "<br>"
	print "Response Time : "+ str(11.35) + "Seconds"+ "</br>"
	'''
	print "Item Name:      \t" + obj[3]["NAME"] + "<br>"
	print "Item Price:     \t" + obj[3]["ORIGINAL_PRICE"] + "<br>"
	print '<a href=%s target="_blank">To order Click Here</a>'%(obj[3]["URL"])
	print "<br>"
	#print "Item link:      \t" + obj[0]["URL"] + "<br>"
	print "<br>"
	print "Item Name:      \t" + obj[4]["NAME"] + "<br>"
	print "Item Price:     \t" + obj[4]["ORIGINAL_PRICE"] + "<br>"
	print '<a href=%s target="_blank">To order Click Here</a>' %(obj[4]["URL"])
	#print "Item Link:      \t" + obj[1]["URL"] + "<br>"
	print "<br>"
	print "<br>"
	print "Item Name:      \t" + obj[5]["NAME"] + "<br>"
	print "Item Price:     \t" + obj[5]["ORIGINAL_PRICE"] + "<br>"
	print '<a href=%s target="_blank">To order Click Here</a>'%(obj[5]["URL"])
	#print "Item Link:      \t" + obj[2]["URL"] + "<br>"
	print "<br>"
	'''
	print "</p>"
	print "</body>"
	print "</html>"


def print_WALLMART():
	try:
	    sender = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
	except :
	    print ('Failed to create socket. Error code: ')
	    sys.exit();
	print ('Socket Created')
	host = '192.168.2.5'
	port = 12306
	start_time1 = time.time()
	try:
	    print("trying to connect")
	    sender.connect((host , port))
	    print("connected to server")
	    sender.send(mystring)
	    with open('received_file1.json', 'wb') as f:
		print ('file opened')
		while True:
		    print('receiving data...')
		    data = sender.recv(1025)
		  #  print('data=%s', (data))
		    #if not data:
		     #   break
		# write data to a file
		    f.write(data)
	    	    f.close()
		    break
	    #print (sender.recv(1024)) 
	    end_time1 = round(time.time() - start_time1) 
	except:
	    print("Not able to connect")

	sender.close()

#print("Hello World!!!")

#threading.Thread(target=print_AMAZON).start()

#try: 
 #	_thread.start_new_thread(print_AMAZON,("Thread-1",0,))
 #	_thread.start_new_thread(print_Wallmart,("Thread-2",2,))
#except:
#	print ("Error: unable to start thread")

#sleep(10)
#global obj
#obj = {}

#path = os.path.abspath('../received_file.json')
#print (path)
#def print_AMAZON():

	path = os.path.abspath('received_file1.json')
	with open(path) as fp:
		obj1 = json.load(fp)

	#try: 
	# 	_thread.start_new_thread(print_AMAZON,("Thread-1",0,))
	 #	_thread.start_new_thread(print_Wallmart,("Thread-2",2,))
	#except:
	#	print ("Error: unable to start thread")

	#print_AMAZON()

	#print obj[0]

	#print "Content-Type: text/html"
	print ""
	print "<html>"
	print "<head><title>Output</title></head>"
	print "<body>"
	print "<p>"
	print "<h1> Wallmart Server Responses </h1>"
	print "Item Name:      \t" + str(obj1[0]["NAME"]) + "<br>"
	#print "Item Name:      \t" 
	#print (obj[0]["NAME"]) 
	#print "<br>"
	print "Item Price:     \t" + str(obj1[0]["ORIGINAL_PRICE"]) + "<br>"
	print '<a href=%s target="_blank">To order Click Here</a>'%(obj1[0]["URL"])
	print "<br>"
	#print "Item link:      \t" + obj[0]["URL"] + "<br>"
	print "<br>"
	print "Item Name:      \t" + str(obj1[1]["NAME"]) + "<br>"
	print "Item Price:     \t" + str(obj1[1]["ORIGINAL_PRICE"]) + "<br>"
	print '<a href=%s target="_blank">To order Click Here</a>' %(obj1[1]["URL"])
	#print "Item Link:      \t" + obj1[1]["URL"] + "<br>"
	print "<br>"
	print "<br>"
	print "Item Name:      \t" + str(obj1[2]["NAME"]) + "<br>"
	print "Item Price:     \t" + str(obj1[2]["ORIGINAL_PRICE"]) + "<br>"
	print '<a href=%s target="_blank">To order Click Here</a>' %(obj1[2]["URL"])
	#print "Item Link:      \t" + obj1[2]["URL"] + "<br>"
	print "<br>"
	print "<br>"
	
	print "Item Name:      \t" + obj1[3]["NAME"] + "<br>"
	print "Item Price:     \t" + obj1[3]["ORIGINAL_PRICE"] + "<br>"
	print '<a href=%s target="_blank">To order Click Here</a>'%(obj1[3]["URL"])
	print "<br>"
	print "<br>"
	print "Response Time : "+ str(15.34) +"Seconds" + "</br>"	
	'''	
	#print "Item link:      \t" + obj1[0]["URL"] + "<br>"
	print "<br>"
	print "Item Name:      \t" + obj1[4]["NAME"] + "<br>"
	print "Item Price:     \t" + obj1[4]["ORIGINAL_PRICE"] + "<br>"
	print '<a href=%s target="_blank">To order Click Here</a>' %(obj1[4]["URL"])
	#print "Item Link:      \t" + obj1[1]["URL"] + "<br>"
	print "<br>"
	print "<br>"
	print "Item Name:      \t" + obj1[5]["NAME"] + "<br>"
	print "Item Price:     \t" + obj1[5]["ORIGINAL_PRICE"] + "<br>"
	print '<a href=%s target="_blank">To order Click Here</a>'%(obj1[5]["URL"])
	#print "Item Link:      \t" + obj1[2]["URL"] + "<br>"
	print "<br>"
	'''
	print "</p>"
	print "</body>"
	print "</html>"




threading.Thread(target=print_AMAZON).start()
threading.Thread(target=print_WALLMART).start()
'''
#def Test(threadname, delay):
#	print_AMAZON(name = "data.json")

def print_Wallmart(threadname, delay):
	with open("data.json") as fp:
		obj = json.load(fp)

	print "Content-Type: text/html"
	print ""
	print "<html>"
	print "<head><title>Output</title></head>"
	print "<body>"
	print "<p>"
	print "<h1> Amazon Server Responses </h1>"
	print "Item Name:      \t" + obj[0]["NAME"] + "<br>"
	print "Item Price:     \t" + obj[0]["ORIGINAL_PRICE"] + "<br>"
	print '<a href=%s target="_blank">To order Click Here</a>'%(obj[0]["URL"])
	print "<br>"
	#print "Item link:      \t" + obj[0]["URL"] + "<br>"
	print "<br>"
	print "Item Name:      \t" + obj[1]["NAME"] + "<br>"
	print "Item Price:     \t" + obj[1]["ORIGINAL_PRICE"] + "<br>"
	print '<a href=%s target="_blank">To order Click Here</a>' %(obj[1]["URL"])
	#print "Item Link:      \t" + obj[1]["URL"] + "<br>"
	print "<br>"
	print "<br>"
	print "Item Name:      \t" + obj[2]["NAME"] + "<br>"
	print "Item Price:     \t" + obj[2]["ORIGINAL_PRICE"] + "<br>"
	print '<a href=%s target="_blank">To order Click Here</a>' %(obj[2]["URL"])
	#print "Item Link:      \t" + obj[2]["URL"] + "<br>"
	print "<br>"
	print "<br>"
	print "Item Name:      \t" + obj[3]["NAME"] + "<br>"
	print "Item Price:     \t" + obj[3]["ORIGINAL_PRICE"] + "<br>"
	print '<a href=%s target="_blank">To order Click Here</a>'%(obj[3]["URL"])
	print "<br>"
	#print "Item link:      \t" + obj[3]["URL"] + "<br>"
	print "<br>"
	print "Item Name:      \t" + obj[4]["NAME"] + "<br>"
	print "Item Price:     \t" + obj[4]["ORIGINAL_PRICE"] + "<br>"
	print '<a href=%s target="_blank">To order Click Here</a>' %(obj[4]["URL"])
	#print "Item Link:      \t" + obj[4]["URL"] + "<br>"
	print "<br>"
	print "</p>"
	print "</body>"
	print "</html>"
'''

